import Foundation
let kJSONRequestURL = "http://api.randomuser.me/"

//: ## Networking!
//: 
//: ----
//: 
//: Just about every app you use involves posting and/or requesting information on the internet.
//: The most common way of forming these network requests involves JSON, a simple key-value format meaning data is queried
//: using keys, often strings like "userID".
//: In this tutorial, you'll learn how to consume and display information from the web on your app!
//: To start, we've just set up a simple app with a button and a couple labels.
//: Go ahead and run the app, and make sure that tapping the button makes an alert appear.

//: Since iOS 7, Apple recommends using **`NSURLSession`** to make network requests.
//: This **`NSURLSession`** forms a connection to the internet for you, so all you have to do is designate the URL and
//: parameters to be sent, and **`NSURLSession`** do the rest.
//: We use **`NSURLSession`**'s **`dataTask`** methods to initiate web requests, so let's fill this in with
//: the URL we want to retrieve data from and a callback to excecute when that data has been retrieved. 
//: First we'll turn the url string into an NSURL object, and feed it into **`NSURLSession.sharedSession().dataTaskWithURL`**.
//: The **`dataTask`** methods return a **`NSURLSessionDataTask`** object, which represents the networking
//: task to be executed. These objects start in the "suspended" state, so we must call the **`resume()`** method to get it going.
//: 
//: ----
//:
//: To do: replace the code within **`buttonTapped`** with the following:
let url = NSURL(string: kJSONRequestURL)!
NSURLSession.sharedSession().dataTaskWithURL(url, completionHandler: { (data, response, error) -> Void in
  NSLog("Request finished: \(response), error: \(error)")
}).resume()
//: Now you've successfully asked the internet for some data!
//: If you run the project and tap the button, eventually a log will show up with
//: the response, or an error indicating that something went wrong along the way. Unfortunately the internet doesn't always
//: work as we want, and you should expect some errors to appear and handle this gracefully in your apps.
//: You might have noticed that it takes a seemingly random amount of time for the log to print. This is because requests to 
//: the internet can be quick, or very long depending on your connection. That's a pretty bad experience for you and the user,
//: nobody knows what's happening after you tap the button. Let's use one of my favorites: **`MBProgressHUD`** to fix that.
//:
//: ----
//:
//: To do: At the top of the ViewController file, underneath **`import UIKit`** add the line:
import MBProgressHUD
//: then change the code inside **`buttonTapped`** to look like this:
@IBAction func buttonTapped(sender: AnyObject) {
  let hud = MBProgressHUD.showHUDAddedTo(view, animated: true)
  NSURLSession.sharedSession().dataTaskWithURL(NSURL(string: kJSONRequestURL)!, completionHandler: { (data, response, error) -> Void in
    hud.hide(true)
    NSLog("Request finished: \(response), error: \(error)")
  }).resume()
}
//: If you run the app, you should notice that the log showed up in the console before the spinner HUD went away,
//: why's that? Well, think back to what we've talked about multi-threaded programming.
//: Which thread is responsible for updating UI? That's right - the main thread! However,
//: we don't want to bog down the main thread with networking, we put that on a background
//: thread (rather - we let Apple do this for us). We need to make sure this code that's doing UI work gets executed 
//: on the main thread. All we need to do to accomplish this is wrap the callback code with a 
//: call to **`dispatch_async`** targeting the main thread. This lets the operating system know that the block of code 
//: should be excecuted on the main thread, not the background thread we're currently running code on.
//:
//: ---
//:
//: To do: Change the code in **`buttonTapped`** to the following:
@IBAction func buttonTapped(sender: AnyObject) {
  let hud = MBProgressHUD.showHUDAddedTo(view, animated: true)
  NSURLSession.sharedSession().dataTaskWithURL(NSURL(string: kJSONRequestURL)!, completionHandler: { (data, response, error) -> Void in
    dispatch_async(dispatch_get_main_queue(), { () -> Void in
      hud.hide(true)
      NSLog("Request finished: \(response), error: \(error)")
    })
  }).resume()
}
//: All better! Now let's do something with the response. Always remember to handle your errors,
//: so we'll start with that.
//:
//: ---
//:
//: Add the following code to make **`buttonTapped`** match this:
@IBAction func buttonTapped(sender: AnyObject) {
  let hud = MBProgressHUD.showHUDAddedTo(view, animated: true)
  NSURLSession.sharedSession().dataTaskWithURL(NSURL(string: kJSONRequestURL)!, completionHandler: { (data, response, error) -> Void in
    dispatch_async(dispatch_get_main_queue(), { () -> Void in
      hud.hide(true)
      
      if error == nil {
        // handle response
      } else {
        UIAlertView(title: "Whoops", message: "Network request failed, check your connection and try again.", delegate: nil, cancelButtonTitle: "Ok").show()
      }
    })
  }).resume()
}
//: There's a problem here, the network request might succeed and return you no data.
//: This is because network responses have a bunch of status codes to give you more
//: information about what happened. If you're interested, you can check out all the status codes
//: listed [here](https://en.wikipedia.org/wiki/List_of_HTTP_status_codes#2xx_Success), but all you 
//: need to know for now is that the 200-range means everything is 👍.
//: This means that we need to do a little better error checking, let's add this function here to make
//: sure that not only is there no error, but the status code of the response is in the 200 range
//:
//: ----
//:
//: add the method below to your ViewController class:
private func requestSucceeded(response: NSURLResponse!, error: NSError!) -> Bool {
  if let httpResponse = response as? NSHTTPURLResponse {
    return error == nil && httpResponse.statusCode >= 200 && httpResponse.statusCode < 300
  }
  
  return false
}
//: then use it in the networking callback:
if self.requestSucceeded(response, error: error) {
  // handle response
} else {
  UIAlertView(title: "Whoops", message: "Network request failed, check your connection and try again.", delegate: nil, cancelButtonTitle: "Ok").show()
}
//: We now use that method to determine a successful request, and let's finally do something
//: with that data coming back. This random user API randomly generates and returns us information about a user. 
//: Let's first visit the "Results" section of [https://randomuser.me](https://randomuser.me) to check out
//: what our data looks like. If you haven't seen JSON before, '[' denote arrays
//: and '{' denote key-value dictionaries. So you'll see that the response comes in the form of a dictionary
//: that contains the field **`results`** as an array of **`users`**. These **`users`** in turn contain field like **`gender`**,
//: **name**, **`email`**, and others. Some of these fields like **`name`** also contain subfields **`first`**, **`last`**, and **`title`**.
//: Now that we know how the data is structured, let's get to dealing with it.
//: 
//: ----
//:
//: To do: add the following method to ViewController:
private func handleResponse(data: NSData) {
  
}
//: then use this method to handle the response in the networking callback
if self.requestSucceeded(response, error: error) {
  self.handleResponse(data)
} else {
  UIAlertView(title: "Whoops", message: "Network request failed, check your connection and try again.", delegate: nil, cancelButtonTitle: "Ok").show()
}
//: We first need to serialize the raw byte data into JSON, luckily for us Apple gives us a nice
//: **`NSJSONSerialization`** class to do so.
//: 
//: ---
//:
//: To do: add code to **`handleResponse`**
let json: AnyObject? = NSJSONSerialization.JSONObjectWithData(data, options: .allZeros, error: nil)
//: We just want to display the name and email, so let's start by grabbing the name from it. We need to 
//: traverse the JSON heirarchy to grab the fields we're interested in. 
//:
//: We know that the JSON returned has a field **`results`**, which is an array. We want the first object in this
//: array, an object with a **`user`** field. We want the **`name`** from that **`user`**, and then we can finally 
//: get to the **`first`** field, a string we can display. That was a long path to get from the whole response down to
//: the name! Don't worry, we've typed up the path for you already.
//: 
//: ----
//: 
//: To do: add this code to the end of **`handleResponse`**
if let first = json["results"][0]["user"]["name"]["first"] as? String {
  
}
//: hmm.. the compiler does not like that! Swift is strict about types, so we've gotta do some casting. 
//: We'll first cast the overall JSON object to what it is: a dictionary, then pull the array of
//: **`users`** out of the **`results`** field. We'll then grab the **`user`** object by grabbing the first object
//: within **`users`** and grabbing the field **`user`** from it, which is another dictionary. We then get the **`name`**
//: field from the **`user`**, yet another dictionary. From **`name`**, we can finally grab the strings: **`first`** and **`last`**.
//:
//: ---
//:
//: To do: add code to end of **`handleResponse`**
private func handleResponse(data: NSData) {
  let json: AnyObject? = NSJSONSerialization.JSONObjectWithData(data, options: .allZeros, error: nil)
  
  if let response = json as? NSDictionary,
    let users = response["results"] as? [AnyObject],
    let user = users[0]["user"] as? NSDictionary,
    let name = user["name"] as? NSDictionary,
    let first = name["first"] as? String,
    let last = name["last"] as? String {
      nameLabel.text = "\(first) \(last)"
  }
}
//: If that code looks bad, it is! We had to do a LOT of work to get the types right as we traversed down the
//: heirarchy of the JSON, and there's a lot of steps that are easy to mess up. **`SwiftyJSON`** comes to the rescue!
//: **`SwiftyJSON`** will allow us to go through multiple levels the JSON heirarchy all at once, and cast to the type we
//: want at the end. If the path is wrong or the final type doesn't match what you asked for, the entire statement
//: will return nil, greatly simplifying our conditions in the if-let statement.
//:
//: **`SwiftyJSON`**'s documentation is available [here](https://github.com/SwiftyJSON/SwiftyJSON#readme), but we'll take
//: you through the steps. First, import the framework at the top of ViewController, underneath the import statements
//: already there.
import SwiftyJSON
//: Then, change the type of our **`json`** object into **`SwiftyJSON`**'s JSON type.
//: To do this, replace the first line of **`handleResponse`** with this line:
let json = JSON(data: data)
//: Finally, we can go through multiple levels of JSON without having to cast at each level! Replace the nasty if-let
//: statement with:
let user = json["results"][0]["user"]
if let first = user["name"]["first"].string,
   let last = user["name"]["last"].string,
   let email = user["email"].string {
  nameLabel.text = "\(first) \(last)"
  emailLabel.text = email
}
//: Whoa, that's much better! Run the app and make sure that a name and email appears when you tap the button.

//: Now what if we have some parameters to send along with the request, or if we want to make a POST request instead of GET? 
//: If that's the case, then we need to set these parameters on a **`NSURLRequest`** object, and use **`NSURLSession`**'s 
//: **`.dataTaskWithRequest`** method(s). 
//:
//: ---
//:
//: Add the following method to your **`ViewController`** class:
private func httpRequest() -> NSURLRequest {
  let request = NSMutableURLRequest(URL: NSURL(string: "http://jsonplaceholder.typicode.com/posts")!)
  request.HTTPMethod = "POST"
  request.addValue("application/json", forHTTPHeaderField: "Content-Type")
  request.addValue("application/json", forHTTPHeaderField: "Accept")
  
  let params = ["title": "hey there", "body": "this is the body"]
  request.HTTPBody = NSJSONSerialization.dataWithJSONObject(params, options: .allZeros, error: nil)
  
  return request
}
//: Notice that you may now specify which type of HTTP request you'd And change your **`buttonTapped`** method to the following:
@IBAction func buttonTapped(sender: AnyObject) {
  let hud = MBProgressHUD.showHUDAddedTo(view, animated: true)
  
  NSURLSession.sharedSession().dataTaskWithRequest(httpRequest(), completionHandler: { (data, response, error) -> Void in
    dispatch_async(dispatch_get_main_queue(), { () -> Void in
      hud.hide(true)
      
      if self.requestSucceeded(response, error: error) {
        self.handleResponse(data)
      } else {
        UIAlertView(title: "Whoops", message: "Network request failed, check your connection and try again.", delegate: nil, cancelButtonTitle: "Ok").show()
      }
    })
  }).resume()
}
//: The data coming back is going to be different now, so change the contents of **`handleResponse`** to match:
private func handleResponse(data: NSData) {
  let json = JSON(data: data)
  if let title = json["title"].string,
     let body = json["body"].string {
    nameLabel.text = title
    emailLabel.text = body
  }
}
//: The url we're POSTing to: [http://jsonplaceholder.typicode.com/posts](http://jsonplaceholder.typicode.com/posts) will 
//: just echo the parameters we sent it, so run the app and you'll see the **`title`** and **`body`** fields in the place
//: of name and email.

//: So now you've done some GET and POST network requests, handled the JSON response, and dealt with performing these
//: networking tasks in a background thread. An iOS networking tutorial wouldn't be complete without mentioning
//: the incredibly popular networking libraries: **`AFNetworking`** and the more Swifty **`Alamofire`**. These libraries
//: include a lot of cool and useful functionality like asynchronus image loading, and simplified code for common
//: networking tasks.
//: 
//: ---
//: 
//: To do: Delete the entire **`httpRequest`** method, and add one more import statement underneath the others
import Alamofire
//: Then change the code within **`buttonTapped`** to:
@IBAction func buttonTapped(sender: AnyObject) {
  let hud = MBProgressHUD.showHUDAddedTo(view, animated: true)

  Alamofire.request(.POST, "http://jsonplaceholder.typicode.com/posts", parameters: ["title": "hey there", "body": "something"])
    .responseJSON(options: .allZeros) { (_, response, data, error) -> Void in
      hud.hide(true)
      
      if self.requestSucceeded(response, error: error) {
        self.handleResponse(data)
      } else {
        NSLog("error: \(error)")
        UIAlertView(title: "Whoops", message: "Network request failed, check your connection and try again.", delegate: nil, cancelButtonTitle: "Ok").show()
      }
  }
}
//: And change **`handleResponse`** to 
private func handleResponse(data: AnyObject) {
  let json = JSON(data)
  if let title = json["title"].string,
     let body = json["body"].string {
    nameLabel.text = title
    emailLabel.text = body
  }
}
//: If you run the app, it should do the same thing as before, but with less code that's a little clearer.
//: Notice that we could drop the **`dispatch_async`** from the networking callback, because **`Alamofire`**
//: has already done that for us.

