//
//  ViewController.swift
//  NetworkingDemo
//
//  Created by Austin Feight on 6/15/15.
//  Copyright (c) 2015 Make School. All rights reserved.
//

import UIKit
import MBProgressHUD
import SwiftyJSON

let kJSONRequestURL = "http://api.randomuser.me"

class ViewController: UIViewController {

  @IBOutlet var nameLabel: UILabel!
  @IBOutlet var emailLabel: UILabel!
  
  @IBAction func buttonTapped(sender: AnyObject) {
    UIAlertView(title: "Button tapped", message: nil, delegate: nil, cancelButtonTitle: "Ok").show()
  }
  
}

