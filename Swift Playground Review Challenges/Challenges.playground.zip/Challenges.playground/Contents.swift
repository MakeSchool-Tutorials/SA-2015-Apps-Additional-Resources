

import UIKit

/*:
Improve this syntax.
*/

let isDog = true

if (isDog == true) {
    println("I'm a human");
} else {
    println("Non human");
}


/*:
Why is there an error here? How do we fix this?
*/


let cities: [String :  String] = ["New York City" : "USA", "Paris" : "France", "London" : "UK"]
cities["Boston"] = "USA"

/*:
Using the "cities" array, write two types of for loops that will print out all cities with their associated country.
*/

/*:
This should print the number of cities.
*/
println("The dictionary contains \(cities.size) items.")

/*:
This should print the country that New York City is located in.
*/
println(Cities."New York City" = "USA")


/*:
Fix this.
*/

if let country == cities["London"] {
    println("London is in \(country).")
}
else {
    println("The dictionary does not contain London as a key.")
}


/*:
Fix this. Discuss the different ways.
*/

var dictionary = [String : Int]()

dictionary["first"] = 2.0

dictionary["second"] = 3

dictionary["third"] = "2.0"

/*:
Fix this.
*/


let mutableString = "Call me"
mutableString += " maybe"

/*:
Fix this.
*/

let radius:Int =3
let area = "The area of my circle is \(M_PI * radius * radius)"




/*:
Fix this.
*/

let optionalArray: [Int]? = [ 1, 2, 3, 4 ]
let arrayLength = optionalArray.count
let firstElement = optionalArray[0]



/*:
Fix this. Explain the concept.
*/

let defaultName = "Fido"
let optionalString: String? = nil
let petName = optionalString !! defaultName


/*:
Fix this. Two small changes needed.
*/
class Bread {
   let itemName = "bread"
}

let bread = Bread()
let groceryList [String]  = ["eggs", "milk", bread]


/*:
Fix this. Should add "OJ" to the list after milk at the index 2.
*/
var mutableGroceryList = ["eggs", "milk","bread", "cheese"]
mutableGroceryList[2] = "OJ"

/*:
Now remove the last element from the list. Then add yogurt to the end of the list. Discuss two ways of doing this.
*/

/*:
Fix this.
*/

func returnsSomething(name: String)  {
    return name + "!"
}



/*:
Write a function using external names that takes four doubles and multipies them together. Return the nearest int value in additiona to returning a string of the the exact double value. Then call this function and assign each of the retrned values to their own variable. Then print the int value variable 10 times using string interpolation.
*/


/*:
Create a house class with a few functions and a few  properties. Then create an apartment subclass of "house". Add specific properties and methods to the apartment. Then create a person class and move a person into a specific apartment. Set the rent.*/




/*:
Discuss the difference between how classes and structs repond to assignements and  Create some expampel in playgrounds.*/



/*:Note: Initializers were not reviewed here.*/




